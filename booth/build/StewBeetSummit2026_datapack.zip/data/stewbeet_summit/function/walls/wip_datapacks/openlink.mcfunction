
#> stewbeet_summit:walls/wip_datapacks/openlink
#
# @executed	positioned 198.5 53.0 -13.5 & rotated 180 0
#
# @within	stewbeet_summit:walls/setup [ positioned 198.5 53.0 -13.5 & rotated 180 0 ]
#

# Open the current page's link dialog (@s is the clicking player thanks to the
# 'execute on target run' in the interaction's callback). The dialog is inlined as
# SNBT so it needs no server restart; linkless pages have no branch (their
# "Open link" hitbox is 0-sized anyway, so this function cannot fire on them)
execute if score #wip_datapacks stewbeet_summit.page matches 0 run return run dialog show @s {"type": "minecraft:multi_action", "title": {"text": "WIP Datapacks", "bold": true, "color": "#FFD479"}, "body": [{"type": "minecraft:plain_message", "width": 240, "contents": {"text": "MC Guns System", "color": "gray"}}], "columns": 1, "actions": [{"label": ["", {"font": "summit_icons:icons", "translate": "summit_icons.github"}, {"text": " "}, {"text": "github.com/Stoupy51/MC_Guns_System", "color": "#8BE9FD"}], "tooltip": {"text": "https://github.com/Stoupy51/MC_Guns_System", "color": "gray"}, "width": 240, "action": {"type": "open_url", "url": "https://github.com/Stoupy51/MC_Guns_System"}}], "exit_action": {"label": {"text": "Close", "color": "red"}}, "can_close_with_escape": true}
execute if score #wip_datapacks stewbeet_summit.page matches 5 run return run dialog show @s {"type": "minecraft:multi_action", "title": {"text": "WIP Datapacks", "bold": true, "color": "#FFD479"}, "body": [{"type": "minecraft:plain_message", "width": 240, "contents": {"text": "ImagineYourCraft", "color": "gray"}}], "columns": 1, "actions": [{"label": ["", {"font": "summit_icons:icons", "translate": "summit_icons.github"}, {"text": " "}, {"text": "github.com/Stoupy51/ImagineYourCraftDatapack", "color": "#8BE9FD"}], "tooltip": {"text": "https://github.com/Stoupy51/ImagineYourCraftDatapack", "color": "gray"}, "width": 240, "action": {"type": "open_url", "url": "https://github.com/Stoupy51/ImagineYourCraftDatapack"}}], "exit_action": {"label": {"text": "Close", "color": "red"}}, "can_close_with_escape": true}

