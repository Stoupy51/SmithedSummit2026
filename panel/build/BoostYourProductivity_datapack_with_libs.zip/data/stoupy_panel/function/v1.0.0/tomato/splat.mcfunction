
#> stoupy_panel:v1.0.0/tomato/splat
#
# @executed	as @e[type=item_display,tag=stoupy_panel.tomato] & at @s
#
# @within	stoupy_panel:v1.0.0/tomato/tick {scale: 0.001, with: {blocks: true, entities: false, on_collision: "function stoupy_panel:v1.0.0/tomato/splat"}}
#			stoupy_panel:v1.0.0/tomato/tick
#			stoupy_panel:v1.0.0/tomato/clear [ as @e[type=item_display,tag=stoupy_panel.tomato] & at @s ]
#

particle minecraft:block{block_state: "minecraft:redstone_block"} ~ ~ ~ 0.25 0.25 0.25 0.12 60 normal @a[distance=..64]
particle minecraft:dust{color: [0.85, 0.1, 0.1], scale: 1.4} ~ ~ ~ 0.3 0.3 0.3 0 25 normal @a[distance=..64]
playsound minecraft:entity.slime.squish_small player @a[distance=..32] ~ ~ ~ 1 1.4
kill @s

