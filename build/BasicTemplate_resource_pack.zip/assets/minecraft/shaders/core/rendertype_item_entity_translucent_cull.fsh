#version 150

layout(std140) uniform Globals {
    ivec3 _;

    vec3 c;
    vec2 ScreenSize;
    float GlintAlpha;
    float GameTime;
    int d;
    int e;
};

layout(std140) uniform Fog {
    vec4 FogColor;
    float u;
    float v;
    float A;
    float B;
    float C;
    float D;
};

float E(float vertexDistance, float F, float G) {
    if (vertexDistance <= F) {
        return 0.;
    } else if (vertexDistance >= G) {
        return 1.;
    }
    return (vertexDistance - F) / (G - F);
}

float H(float I, float J, float K, float L, float M, float N) {
    return max(E(I, K, L), E(J, M, N));
}

vec4 O(vec4 P, float I, float J, float K, float L, float M, float N, vec4 Q) {
    float R = H(I, J, K, L, M, N);
    return vec4(mix(P.rgb, Q.rgb, R * Q.a), P.a);
}

float S(vec3 T) {
    return length(T);
}

float U(vec3 T) {
    float V = length(T.xz);
    float W = abs(T.y);
    return max(V, W);
}

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

uniform sampler2D Sampler0;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in vec3 a_;
out vec4 fragColor;
in vec3 c_;

const float f_ = 3.1415926536;
const float g_ = f_ * 2.;
const vec3 h_ = vec3(0., -.4, -.9);
const float i_ = .4;
const float j_ = .5;
const float k_ = 1;
const vec3 l_ = vec3(.64, 0., 0.);
const float m_ = .1;
const float n_ = -1.;
const float o_ = 1.;
const vec3 p_ = vec3(.04, .3, .47);
const float q_ = 4.;

vec4 r_(vec3 s_, float t_) {
    vec4 u_ = vec4(0.);
    float t = t_;
    for (float z = 0., v_ = 0., w_ = 0.; w_ < 20.; w_++) {
        vec3 p = z * normalize(s_);
        p = vec3(atan(p.y / .2, p.x) * 2., p.z / 3., length(p.xy) - 5. - z * .2);
        for (v_ = 1.; v_ < 7.; v_++) {
            p += sin(p.yzx * v_ + t + .3 * w_) / v_;
        }
        z += v_ = length(vec4(.4 * cos(p) - .4, p.z));
        u_ += (cos(p.x + w_ * .4 + z + vec4(6., 1., 2., 0.)) + 1.) / v_;
    }
    u_ = tanh(u_ * u_ / 4e2);
    return u_;
}

vec4 x_() {
    vec3 y_ = normalize(c_);
    vec3 z_ = h_ * (GameTime * j_);
    vec3 A_ = z_;
    float B_ = dot(h_, y_);
    float C_ = dot(h_, A_);
    float a = 1. - B_ * B_;
    float b = 2. * (dot(y_, A_) - B_ * C_);
    float D_ = dot(A_, A_) - C_ * C_ - i_ * i_;
    float E_ = b * b - 4. * a * D_;
    if (E_ < 0.) {
        discard;
    }
    float F_ = sqrt(E_);
    float G_ = 1. / (2. * a);
    float H_ = (-b - F_) * G_;
    float I_ = (-b + F_) * G_;
    float t = -1.;
    if (H_ > 0. && I_ > 0.) {
        t = min(H_, I_);
    } else if (H_ > 0.) {
        t = H_;
    } else if (I_ > 0.) {
        t = I_;
    }
    if (t < 0.) {
        discard;
    }
    vec3 J_ = z_ + y_ * t;
    vec3 K_ = h_;
    vec3 L_ = abs(K_.y) < .9 ? vec3(0., 1., 0.) : vec3(1., 0., 0.);
    vec3 M_ = normalize(cross(K_, L_));
    vec3 N_ = cross(K_, M_);
    vec3 O_ = vec3(dot(J_, M_), dot(J_, N_), dot(J_, K_));
    vec4 l = r_(O_, GameTime * 320.);
    vec3 P_ = h_ * dot(J_, h_);
    vec3 normal = normalize(J_ - P_);
    float Q_ = 1. - max(0., dot(normal, -y_));
    float R_ = pow(Q_, q_);
    vec3 S_ = p_ * R_ * k_;
    float T_ = dot(J_, h_);
    float U_ = exp(-T_ * T_ * m_);
    vec3 V_ = l_ * U_ * k_;
    l.rgb = vec3(1.) - (vec3(1.) - l.rgb) * (vec3(1.) - S_);
    l.rgb = vec3(1.) - (vec3(1.) - l.rgb) * (vec3(1.) - V_);
    float W_ = smoothstep(n_, o_, T_);
    l.a *= W_;
    vec4 X_ = vec4(0., 0., 0., 1.);
    vec4 Y_ = mix(X_, l, l.a);
    Y_.a = 1;
    return Y_;
}

const float Z_ = 1.1;
const float _a = 10.03;
const float ca = .5;
const float da = .3;
const float ea = .2;
const float fa = 8.;
const float ha = .5;
const vec3 ia = vec3(.2, .4, .6);
const vec3 ja = vec3(.4, .7, 1.);
const mat2 ka = mat2(1.6, 1.2, -1.2, 1.6);

vec2 la(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return -1. + 2. * fract(sin(p) * 43758.54531);
}

float ma(in vec2 p) {
    const float na = .366025404;
    const float oa = .211324865;
    vec2 w_ = floor(p + (p.x + p.y) * na);
    vec2 a = p - w_ + (w_.x + w_.y) * oa;
    vec2 u_ = (a.x > a.y) ? vec2(1., 0.) : vec2(0., 1.);
    vec2 b = a - u_ + oa;
    vec2 D_ = a - 1. + 2. * oa;
    vec3 E_ = max(.5 - vec3(dot(a, a), dot(b, b), dot(D_, D_)), 0.);
    vec3 pa = E_ * E_ * E_ * E_ * vec3(dot(a, la(w_ + 0.)), dot(b, la(w_ + u_)), dot(D_, la(w_ + 1.)));
    return dot(pa, vec3(70.));
}

float qa(vec2 pa) {
    float sa = 0., ta = .1;
    for (int w_ = 0; w_ < 7; w_++) {
        sa += ma(pa) * ta;
        pa = ka * pa;
        ta *= .4;
    }
    return sa;
}

vec3 ua(vec3 va) {
    vec2 wa = va.xz / (abs(va.y) + .2);
    wa *= .3;
    float t_ = GameTime * _a;
    float q = qa(wa * Z_ * .5);
    float r = 0.;
    vec2 xa = wa * Z_;
    xa -= q - t_;
    float ya = .8;
    for (int w_ = 0; w_ < 6; w_++) {
        r += abs(ya * ma(xa));
        xa = ka * xa + t_;
        ya *= .7;
    }
    float za = 0.;
    xa = wa * Z_;
    xa -= q - t_;
    ya = .7;
    for (int w_ = 0; w_ < 6; w_++) {
        za += ya * ma(xa);
        xa = ka * xa + t_;
        ya *= .6;
    }
    za *= r + za;
    float D_ = 0.;
    t_ = GameTime * _a * 2.;
    xa = wa * Z_ * 2.;
    xa -= q - t_;
    ya = .4;
    for (int w_ = 0; w_ < 5; w_++) {
        D_ += ya * ma(xa);
        xa = ka * xa + t_;
        ya *= .6;
    }
    float Aa = 0.;
    t_ = GameTime * _a * 3.;
    xa = wa * Z_ * 3.;
    xa -= q - t_;
    ya = .4;
    for (int w_ = 0; w_ < 5; w_++) {
        Aa += abs(ya * ma(xa));
        xa = ka * xa + t_;
        ya *= .6;
    }
    D_ += Aa;
    float Ba = va.y * .5 + .5;
    vec3 Ca = mix(ja, ia, Ba);
    vec3 Da = vec3(1.1, 1.1, .9) * clamp((ca + da * D_), 0., 1.);
    za = ea + fa * za * r;
    float Ea = smoothstep(.15, .5, va.y);
    za *= Ea;
    D_ *= Ea;
    Aa *= Ea;
    vec3 Fa = mix(Ca, clamp(ha * Ca + Da, 0., 1.), clamp(za + D_, 0., 1.));
    return Fa;
}

vec4 Ga() {
    vec3 Ha = normalize(a_);
    vec3 Ga = ua(Ha);
    return vec4(Ga, 1.);
}

vec3 Ia;
vec3 E_;

float Ja(vec3 p, float t_);
vec2 Ka(vec3 T, vec3 y_, float t_);

vec2 La(vec2 p, float Ma) {
    float Na = (f_ * 2.0) / Ma;
    float a = atan(p.y, p.x) + Na * .5;
    a = mod(a, Na) - Na * .5;
    return vec2(cos(a), sin(a)) * length(p);
}

float Ja(vec3 p, float t_) {
    float Oa;
    float Pa = 1e5;
    vec3 Qa = p;
    Oa = step(-1. + cos(floor(p.z * 6.) / 6. + t_ * 1.) * 3.14, mod(atan(p.x, p.y), 6.28) - 3.14)
       * step(mod(atan(p.x, p.y), 6.28) - 3.14 - 1.5, -1. + cos(floor(p.z * 3.) / 1. + t_ * 1.) * 3.14)
       * step(0., (length(fract(vec2(Qa.z, min(abs(Qa.x), abs(Qa.y))) * 10.) - .5) - .2));
    Oa = cos(Oa * 1. + floor(p.z) + t_ * (mod(floor(p.z), 2.) - 1. == 0. ? -1. : 1.));
    float Ra = 1e5;
    Ia = 1. - vec3(.5 - Oa * .5, .5, .3 + Oa * .5);
    Pa = length(p.xy) - 1. + .1 * Oa;
    Pa = max(Pa, Oa * -(length(fract(vec2(Qa.z, min(abs(Qa.x), abs(Qa.y))) * 10.) - .5) - .1));
    Pa = max(Pa, -(length(p.xy) - .9 + .1 * Oa));
    p.xy = La(p.yx, 50. + 50. * sin(p.z * .25));
    p.z = fract(p.z * 3.) - .5;
    if (Oa != 0.) {
        Ra = length(p.zy) - .0251 - .25 * sin(Qa.z * 5.5);
        Ra = max(Ra, -p.x + .4 + clamp(Oa, 0., 1.));
    }
    Pa = min(Pa, Ra);
    E_ += vec3(.5, .8, .5) * (Oa != 0. ? 1. : 0.) * .0125 / (.01 + max(Pa - Oa * .1, 1e-4) * max(Pa - Oa * .1, 1e-4));
    return Pa;
}

vec2 Ka(vec3 T, vec3 y_, float t_) {
    vec2 Sa = vec2(0., 0.);
    vec3 p = vec3(0., 0., 0.);
    vec2 s = vec2(0., 0.);
    for (float w_ = -1.; w_ < 200.0; ++w_) {
        p = T + y_ * Sa.y;
        Sa.x = Ja(p, t_);
        Sa.y += Sa.x * .2;
        if (Sa.x < 0.0001 || Sa.y > 50.0) {
            break;
        }
        s.x++;
    }
    s.y = Sa.y;
    return s;
}

vec4 Ta() {
    float t = GameTime * 300.125;
    vec3 Ua = vec3(0.);
    vec3 y_ = normalize(c_);
    vec3 T = vec3(0., 0., 4.5 - GameTime * 2e2);
    E_ = vec3(0.);
    vec2 Va = Ka(T, y_, t);
    if (Va.y <= 50.0) {
        Ua.xyz = Ia * (1. - Va.x * .0025);
    } else {
        Ua = vec3(0.);
    }
    Ua += E_ * .005125;
    return vec4(Ua, 1.);
}

float Wa(vec3 p, float t_) {
    p.xy *= mat2(cos(p.z * .2 + vec4(0, 33, 11, 0)));
    float distance = sin(p.y + p.x);
    for (float pa = 1.; pa < 32.; pa += pa) {
        vec3 Xa = cos(.3 * t_ + p * pa);
        distance -= abs(dot(Xa, vec3(.3))) / pa;
    }
    return distance;
}

vec4 Ya() {
    vec3 Za = normalize(c_);
    vec3 z_ = vec3(0., 0., -2. * GameTime * 4e3);
    float _b = 0.;
    float cb = 0.;
    vec4 db = vec4(0.);
    for (int w_ = 0; w_ < 100; w_++) {
        vec3 p = z_ + Za * _b;
        cb = Wa(p, GameTime);
        _b += .01 + abs(cb) * .8;
        db += 1. / (abs(cb) + 1e-3);
        if (_b > 50.) {
            break;
        }
    }
    vec4 eb = db / 2e4;
    eb /= length(Za.xy);
    eb = tanh(eb);
    return vec4(eb.rrr, eb.r);
}

vec4 fb() {
    float t_ = GameTime * 1400;
    float _b = 0.;
    float cb = 0.;
    vec4 db = vec4(0.);
    vec3 Za = normalize(c_);
    for (int w_ = 0; w_ < 200; w_++) {
        vec3 p = Za * _b;
        p.z += 9.;
        vec3 hb = normalize(cos(vec3(0, 1, 0) + t_ - .4 * cb));
        vec3 ib = hb * dot(hb, p) - cross(hb, p);
        vec3 jb = ib;
        float kb;
        for (kb = 1.; kb++ < 6.;) {
            jb += cos(jb * kb + t_).yzx / kb;
        }
        cb = length(jb);
        float lb = .1 * (abs(sin(cb - t_)) + abs(jb.y) / kb);
        _b += lb;
        if (lb > 0.) {
            db += (cos(cb / .6 + vec4(0, 1, 2, 0)) + 1.1) / lb;
        }
        if (_b > 25.) {
            break;
        }
    }
    vec4 eb = tanh(db * db / 2e7);
    return vec4(eb.rgb, 1.);
}

#define mb(x) fract(sin(x) * 43758.5453123)

float nb(float x, float pa) {
    const float ob = .3;
    float w_ = floor(x);
    float za = x - w_;
    float pb = smoothstep(.5 - ob, .5 + ob, za);
    float qb = mix(floor(mb(w_) * pa), floor(mb(w_ + 1.) * pa), pb);
    qb /= (pa - 1.) * .5;
    return qb - 1.;
}

vec3 sb(vec3 p) {
    vec3 offset = vec3(0.);
    offset.x += nb(p.z * .05, 5.) * 5.;
    offset.y += nb(p.z * .07, 3.975) * 5.;
    return offset;
}

float tb(vec2 p, float s) {
    p = abs(p);
    return (p.x + p.y - s) * inversesqrt(2.);
}

vec3 ub(vec3 p, vec3 vb, float t) {
    return mix(dot(vb, p) * vb, p, cos(t)) + cross(vb, p) * sin(t);
}

vec4 wb() {
    vec3 Ua = vec3(0.);
    float t_ = GameTime * 500;
    vec3 xb = vec3(0., 0., -1. + t_ * 5.);
    vec3 yb = vec3(0., 0., 0. + t_ * 5.);
    xb += sb(xb);
    yb += sb(yb);
    vec3 z = normalize(yb - xb);
    vec3 x = normalize(vec3(z.z, 0., -z.x));
    vec3 y = cross(z, x);
    mat3 zb = mat3(x, y, z);
    float Ab = nb(t_ + mb(c_.x * c_.y * t_) * .05, 6.);
    vec3 Bb = zb * ub(normalize(c_), vec3(0., 0., 1.), Ab);
    float w_ = 0., Cb = 0., g = 0.;
    for (; w_++ < 99.;) {
        vec3 p = xb + Bb * g;
        p -= sb(p);
        float r = 0.;
        vec3 pp = p;
        float Db = 1.;
        for (float Eb = 0.; Eb++ < 4.;) {
            r = clamp(r + abs(dot(sin(pp * 3.), cos(pp.yzx * 2.)) * .3 - .1) / Db, -.5, .5);
            pp = ub(pp, normalize(vec3(.1, .2, .3)), .785 + Eb);
            pp += pp.yzx + Eb * 50.;
            Db *= 1.5;
            pp *= 1.5;
        }
        float E_ = abs(tb(p.xy, 7.)) - 3. - r;
        vec3 Fb = ub(p, vec3(0., 0., 1.), sb(p).x * .5 + p.z * .2);
        float t = length(abs(Fb.xy) - .5) - .1;
        E_ = min(t, E_);
        Cb = max(1e-3, E_);
        g += Cb;
        vec3 Gb = vec3(.3, .2, .1) * (1e2 * exp(-20. * fract(p.z * .25 + t_)));
        Gb *= mod(floor(p.z * 4.) + mod(floor(p.y * 4.), 2.), 2.);
        vec3 Hb = vec3(.1);
        vec3 Ib = (t < E_) ? Gb : Hb;
        Ua += Ib * .0325 / exp(w_ * w_ * Cb);
    }
    Ua = mix(Ua, vec3(.9, .9, 1.1), 1. - exp(-.01 * g * g * g));
    return vec4(Ua, 1.);
}

vec3 Jb(vec3 x) {
    return x - floor(x * (1. / 289.)) * 289.;
}

vec4 Jb(vec4 x) {
    return x - floor(x * (1. / 289.)) * 289.;
}

vec4 Kb(vec4 x) {
    return Jb(((x * 34.) + 1.) * x);
}

vec4 Lb(vec4 r) {
    return 1.792842914 - .853734721 * r;
}

float Mb(vec3 Nb) {
    const vec2 Ob = vec2(1. / 6., 1. / 3.);
    const vec4 Pb = vec4(0., .5, 1., 2.);
    vec3 w_ = floor(Nb + dot(Nb, Ob.yyy));
    vec3 Qb = Nb - w_ + dot(w_, Ob.xxx);
    vec3 g = step(Qb.yzx, Qb.xyz);
    vec3 Rb = 1. - g;
    vec3 Sb = min(g.xyz, Rb.zxy);
    vec3 Tb = max(g.xyz, Rb.zxy);
    vec3 Ub = Qb - Sb + Ob.xxx;
    vec3 Vb = Qb - Tb + Ob.yyy;
    vec3 Wb = Qb - Pb.yyy;
    w_ = Jb(w_);
    vec4 p = Kb(Kb(Kb(w_.z + vec4(0., Sb.z, Tb.z, 1.)) + w_.y + vec4(0., Sb.y, Tb.y, 1.)) + w_.x + vec4(0., Sb.x, Tb.x, 1.));
    float Xb = 0.142857142857;
    vec3 Yb = Xb * Pb.wyz - Pb.xzx;
    vec4 Eb = p - 49. * floor(p * Yb.z * Yb.z);
    vec4 Zb = floor(Eb * Yb.z);
    vec4 _c = floor(Eb - 7. * Zb);
    vec4 x = Zb * Yb.x + Yb.yyyy;
    vec4 y = _c * Yb.x + Yb.yyyy;
    vec4 E_ = 1. - abs(x) - abs(y);
    vec4 ac = vec4(x.xy, y.xy);
    vec4 bc = vec4(x.zw, y.zw);
    vec4 cc = floor(ac) * 2. + 1.;
    vec4 dc = floor(bc) * 2. + 1.;
    vec4 ec = -step(E_, vec4(0.));
    vec4 fc = ac.xzyw + cc.xzyw * ec.xxyy;
    vec4 gc = bc.xzyw + dc.xzyw * ec.zzww;
    vec3 hc = vec3(fc.xy, E_.x);
    vec3 ic = vec3(fc.zw, E_.y);
    vec3 jc = vec3(gc.xy, E_.z);
    vec3 kc = vec3(gc.zw, E_.w);
    vec4 lc = Lb(vec4(dot(hc, hc), dot(ic, ic), dot(jc, jc), dot(kc, kc)));
    hc *= lc.x;
    ic *= lc.y;
    jc *= lc.z;
    kc *= lc.w;
    vec4 ka = max(.6 - vec4(dot(Qb, Qb), dot(Ub, Ub), dot(Vb, Vb), dot(Wb, Wb)), 0.);
    ka = ka * ka;
    return 42. * dot(ka * ka, vec4(dot(hc, Qb), dot(ic, Ub), dot(jc, Vb), dot(kc, Wb)));
}

float mc(in vec3 p) {
    vec3 q = p - vec3(0., .1, 1.) * GameTime;
    float za;
    za = .5 * Mb(q);
    q *= 2.02;
    za += .25 * Mb(q);
    q *= 2.03;
    za += .125 * Mb(q);
    q *= 2.01;
    za += .0625 * Mb(q);
    q *= 2.02;
    za += .03125 * Mb(q);
    return clamp(1.5 - p.y - 2. + 1.75 * za, 0., 1.);
}

float nc(in vec3 p) {
    vec3 q = p - vec3(0., .1, 1.) * GameTime;
    float za;
    za = .5 * Mb(q);
    q *= 2.02;
    za += .25 * Mb(q);
    q *= 2.03;
    za += .125 * Mb(q);
    q *= 2.01;
    za += .0625 * Mb(q);
    return clamp(1.5 - p.y - 2. + 1.75 * za, 0., 1.);
}

float oc(in vec3 p) {
    vec3 q = p - vec3(0., .1, 1.) * GameTime;
    float za;
    za = .5 * Mb(q);
    q *= 2.02;
    za += .25 * Mb(q);
    q *= 2.03;
    za += .125 * Mb(q);
    return clamp(1.5 - p.y - 2. + 1.75 * za, 0., 1.);
}

float pc(in vec3 p) {
    vec3 q = p - vec3(0., .1, 1.) * GameTime;
    float za;
    za = .5 * Mb(q);
    q *= 2.02;
    za += .25 * Mb(q);
    return clamp(1.5 - p.y - 2. + 1.75 * za, 0., 1.);
}

const vec3 qc = vec3(-.7071, 0., -.7071);

vec4 rc(in vec3 xb, in vec3 Bb, in vec3 sc) {
    vec4 tc = vec4(0.);
    float t = 0.;
    for (int w_ = 0; w_ < 40; w_++) {
        vec3 T = xb + t * Bb;
        if (T.y < -3. || T.y > 2. || tc.a > .99) break;
        float uc = mc(T);
        if (uc > .01) {
            float vc = clamp((uc - mc(T + .3 * qc)) / .6, 0., 1.);
            vec3 wc = vec3(1., .6, .3) * vc + vec3(.91, .98, 1.05);
            vec4 Ua = vec4(mix(vec3(1., .95, .8), vec3(.25, .3, .35), uc), uc);
            Ua.xyz *= wc;
            Ua.xyz = mix(Ua.xyz, sc, 1. - exp(-3e-3 * t * t));
            Ua.w *= .4;
            Ua.rgb *= Ua.a;
            tc += Ua * (1. - tc.a);
        }
        t += max(.06, .05 * t);
    }
    for (int w_ = 0; w_ < 40; w_++) {
        vec3 T = xb + t * Bb;
        if (T.y < -3. || T.y > 2. || tc.a > .99) break;
        float uc = nc(T);
        if (uc > .01) {
            float vc = clamp((uc - nc(T + .3 * qc)) / .6, 0., 1.);
            vec3 wc = vec3(1., .6, .3) * vc + vec3(.91, .98, 1.05);
            vec4 Ua = vec4(mix(vec3(1., .95, .8), vec3(.25, .3, .35), uc), uc);
            Ua.xyz *= wc;
            Ua.xyz = mix(Ua.xyz, sc, 1. - exp(-3e-3 * t * t));
            Ua.w *= .4;
            Ua.rgb *= Ua.a;
            tc += Ua * (1. - tc.a);
        }
        t += max(.06, .05 * t);
    }
    for (int w_ = 0; w_ < 30; w_++) {
        vec3 T = xb + t * Bb;
        if (T.y < -3. || T.y > 2. || tc.a > .99) break;
        float uc = oc(T);
        if (uc > .01) {
            float vc = clamp((uc - oc(T + .3 * qc)) / .6, 0., 1.);
            vec3 wc = vec3(1., .6, .3) * vc + vec3(.91, .98, 1.05);
            vec4 Ua = vec4(mix(vec3(1., .95, .8), vec3(.25, .3, .35), uc), uc);
            Ua.xyz *= wc;
            Ua.xyz = mix(Ua.xyz, sc, 1. - exp(-3e-3 * t * t));
            Ua.w *= .4;
            Ua.rgb *= Ua.a;
            tc += Ua * (1. - tc.a);
        }
        t += max(.06, .05 * t);
    }
    for (int w_ = 0; w_ < 30; w_++) {
        vec3 T = xb + t * Bb;
        if (T.y < -3. || T.y > 2. || tc.a > .99) break;
        float uc = pc(T);
        if (uc > .01) {
            float vc = clamp((uc - pc(T + .3 * qc)) / .6, 0., 1.);
            vec3 wc = vec3(1., .6, .3) * vc + vec3(.91, .98, 1.05);
            vec4 Ua = vec4(mix(vec3(1., .95, .8), vec3(.25, .3, .35), uc), uc);
            Ua.xyz *= wc;
            Ua.xyz = mix(Ua.xyz, sc, 1. - exp(-3e-3 * t * t));
            Ua.w *= .4;
            Ua.rgb *= Ua.a;
            tc += Ua * (1. - tc.a);
        }
        t += max(.06, .05 * t);
    }
    return clamp(tc, 0., 1.);
}

vec4 xc(in vec3 xb, in vec3 Bb) {
    float yc = clamp(dot(qc, Bb), 0., 1.);
    vec3 Ua = vec3(.6, .71, .75) - Bb.y * .2 * vec3(1., .5, 1.) + .15 * .5;
    Ua += .2 * vec3(1., .6, .1) * pow(yc, 8.);
    vec4 qb = rc(xb, Bb, Ua);
    Ua = Ua * (1. - qb.w) + qb.xyz;
    Ua += vec3(.2, .08, .04) * pow(yc, 3.);
    return vec4(Ua, 1.);
}

vec4 zc() {
    vec3 xb = vec3(0., 0., 1. * GameTime * 2e2);
    vec3 Bb = normalize(c_);
    return xc(xb, Bb);
}

const float Ac = .38;
const float Bc = 1.;
const float Cc = 1.5;
const int Dc = 12;
const int Ec = 36;

vec2 Fc(vec2 Y, vec2 Gc, float Hc, float Ic) {
    float x = dot(Gc, Y) * Hc + Ic;
    float Jc = exp(sin(x) - 1.);
    float Kc = Jc * cos(x);
    return vec2(Jc, -Kc);
}

float Lc(vec2 Y, int Mc, float t_) {
    float Nc = length(Y) * .1;
    float Oc = 0.;
    float Hc = 1.;
    float Pc = 2.;
    float ya = 1.;
    float Qc = 0.;
    float Rc = 0.;
    for (int w_ = 0; w_ < Mc; w_++) {
        vec2 p = vec2(sin(Oc), cos(Oc));
        vec2 qb = Fc(Y, p, Hc, t_ * Pc + Nc);
        Y += p * qb.y * ya * Ac;
        Qc += qb.x * ya;
        Rc += ya;
        ya = mix(ya, 0., .2);
        Hc *= 1.18;
        Pc *= 1.07;
        Oc += 1232.399963;
    }
    return Qc / Rc;
}

float Sc(vec3 Tc, vec3 Uc, vec3 Vc, float Wc, float t_) {
    vec3 T = Uc;
    vec3 y_ = normalize(Vc - Uc);
    for (int w_ = 0; w_ < 64; w_++) {
        float Xc = Lc(T.xz, Dc, t_) * Wc - Wc;
        if (Xc + .01 > T.y) {
            return distance(T, Tc);
        }
        T += y_ * (T.y - Xc);
    }
    return distance(Uc, Tc);
}

vec3 Yc(vec2 T, float Cb, float Wc, float t_) {
    vec2 Zc = vec2(Cb, 0);
    float _d = Lc(T.xy, Ec, t_) * Wc;
    vec3 a = vec3(T.x, _d, T.y);
    return normalize(cross(
        a - vec3(T.x - Cb, Lc(T.xy - Zc.xy, Ec, t_) * Wc, T.y),
        a - vec3(T.x, Lc(T.xy + Zc.yx, Ec, t_) * Wc, T.y + Cb)
    ));
}

float ad(vec3 bd, vec3 Gc, vec3 cd, vec3 normal) {
    return clamp(dot(cd - bd, normal) / dot(Gc, normal), -1., 9991999.);
}

vec3 dd(float t_) {
    return normalize(vec3(-.077, .5 + sin(t_ * .2 + 2.6) * .45, .577));
}

vec3 ed(vec3 fd, vec3 qc) {
    float gd = 1. / (fd.y * 1. + .1);
    float hd = 1. / (qc.y * 11. + 1.);
    float id = pow(abs(dot(qc, fd)), 2.);
    float jd = pow(max(0., dot(qc, fd)), 8.);
    float kd = jd * gd * .2;
    vec3 ld = mix(vec3(1.), max(vec3(0.), vec3(1.) - vec3(5.5, 13., 22.4) / 22.4), hd);
    vec3 md = vec3(5.5, 13., 22.4) / 22.4 * ld;
    vec3 nd = max(vec3(0.), md - vec3(5.5, 13., 22.4) * 2e-3 * (gd + -6. * qc.y * qc.y));
    nd *= gd * (.24 + id * .24);
    return nd * (1. + 1. * pow(1. - fd.y, 3.));
}

float od(vec3 y_, vec3 qc) {
    return pow(max(0., dot(y_, qc)), 720.) * 210.;
}

vec3 pd(vec3 l) {
    mat3 qd = mat3(.59719, .076, .0284, .35458, .90834, .13383, .04823, .01566, .83777);
    mat3 rd = mat3(1.60475, -.10208, -.00327, -.53108, 1.10813, -.07276, -.07367, -.00605, 1.07602);
    vec3 Nb = qd * l;
    vec3 a = Nb * (Nb + .0245786) - 9.0537e-5;
    vec3 b = Nb * (.983729 * Nb + .432951) + .238081;
    return pow(clamp(rd * (a / b), 0., 1.), vec3(1. / 2.2));
}

vec4 sd() {
    float t_ = GameTime * 400;
    vec3 td = normalize(c_);
    vec3 qc = dd(0.);
    if (td.y >= 0.) {
        vec3 l = ed(td, qc) * .5 + od(td, qc);
        return vec4(pd(l * 2.), 1.);
    }
    vec3 bd = vec3(t_ * .2, Cc, 1.);
    vec3 ud = vec3(0., 0., 0.);
    vec3 vd = vec3(0., -Bc, 0.);
    float wd = ad(bd, td, ud, vec3(0., 1., 0.));
    float xd = ad(bd, td, vd, vec3(0., 1., 0.));
    vec3 yd = bd + td * wd;
    vec3 zd = bd + td * xd;
    float Sa = Sc(bd, yd, zd, Bc, t_);
    vec3 Ad = bd + td * Sa;
    vec3 Bd = Yc(Ad.xz, .01, Bc, t_);
    Bd = mix(Bd, vec3(0., 1., 0.), .8 * min(1., sqrt(Sa * .01) * 1.1));
    float Cd = (.04 + (1. - .04) * (pow(1. - max(0., dot(-Bd, td)), 5.)));
    vec3 Dd = normalize(reflect(td, Bd));
    Dd.y = abs(Dd.y);
    vec3 Ed = ed(Dd, qc) * .5 + od(Dd, qc);
    vec3 Fd = vec3(.0293, .0698, .1717) * .1 * (.2 + (Ad.y + Bc) / Bc);
    vec3 l = Cd * Ed + Fd;
    return vec4(pd(l * 2.), 1.);
}

vec4 Gd() {
    float t_ = GameTime * 2000;
    float z = 0.;
    float v_ = 0.;
    float s = 0.;
    vec3 y_ = normalize(c_);
    vec3 Ua = vec3(0);
    for (float w_ = 0.; w_ < 100.0; w_++) {
        vec3 p = z * y_;
        for (float Eb = 0., za = 5.0; Eb < 8.0; Eb++, za *= 1.8) {
            p += 0.6 * sin(p * za - vec3(0.2) * t_).yzx / za;
        }
        s = .3 - abs(p.y);
        v_ = 0.005 + max(s, -s * 0.2) / 4.;
        z += v_;
        float Hd = 14.0 * s + dot(p, vec3(1, -1, 0)) + 0.5 * t_;
        vec3 Id = (cos(Hd - vec3(0.0, 1.0, 2.0)) + 1.5) * exp(s * 10.0) / v_;
        Ua += Id;
    }
    Ua *= 0.005 / 100.0 * 1.0;
    return vec4(tanh(Ua * Ua), 1.);
}

mat2 Jd(in float a) {
    float D_ = cos(a), s = sin(a);
    return mat2(D_, s, -s, D_);
}

const mat2 rd = mat2(.95534, .29552, -.29552, .95534);

float Kd(in float x) {
    return clamp(abs(fract(x) - .5), .01, .49);
}

vec2 Ld(in vec2 p) {
    return vec2(Kd(p.x) + Kd(p.y), Kd(p.y + Kd(p.x)));
}

float Md(in vec2 pa) {
    return fract(sin(dot(pa, vec2(12.9898, 4.1414))) * 43758.5453);
}

float Nd(in vec2 p, float Od) {
    float z = 1.8;
    float Pd = 2.5;
    float Qd = 0.;
    p *= Jd(p.x * .06);
    vec2 Rd = p;
    for (float w_ = 0.; w_ < 5.; w_++) {
        vec2 Sd = Ld(Rd * 1.85) * .75;
        Sd *= Jd(GameTime * Od);
        p -= Sd / Pd;
        Rd *= 1.3;
        Pd *= .45;
        z *= .42;
        p *= 1.21 + (Qd - 1.) * .02;
        Qd += Kd(p.x + Kd(p.y)) * z;
        p *= -rd;
    }
    return clamp(1. / pow(Qd * 29., 1.3), 0., .55);
}

vec4 Td(vec3 xb, vec3 Bb) {
    vec4 Ua = vec4(0);
    vec4 Ud = vec4(0);
    for (float w_ = 0.; w_ < 50.; w_++) {
        float Vd = 6e-3 * Md(c_.xy * 1e2) * smoothstep(0., 15., w_);
        float pt = ((.8 + pow(w_, 1.4) * 2e-3) - xb.y) / (Bb.y * 2. + .4);
        pt -= Vd;
        if (pt < 0.) continue;
        vec3 Wd = xb + pt * Bb;
        vec2 p = Wd.zx;
        float Xd = Nd(p, 2e2);
        vec4 Yd = vec4(0, 0, 0, Xd);
        Yd.rgb = (sin(1. - vec3(2.15, -.5, 1.2) + w_ * .043) * .5 + .5) * Xd;
        Ud = mix(Ud, Yd, .5);
        Ua += Ud * exp2(-w_ * .065 - 2.5) * smoothstep(0., 5., w_);
    }
    Ua *= (clamp(Bb.y * 15. + .4, 0., 1.));
    return Ua * 1.8;
}

vec4 Zd() {
    vec3 Bb = normalize(c_);
    vec3 xb = vec3(0., 0., 0.);
    vec4 l = vec4(0.);
    if (Bb.y > 0.) {
        vec4 _e = smoothstep(0., 1.5, Td(xb, Bb));
        float ae = smoothstep(0., .01, abs(Bb.y)) * .1 + .9;
        _e *= ae;
        l = vec4(_e.rgb, _e.a);
    }
    return l;
}

vec4 be() {
    vec3 y_ = normalize(vec3(c_.xy, c_.z / 0.800));
    float t_ = GameTime * 0.110;
    float ce = t_ * .2;
    float de = t_ * .1;
    mat2 ee = mat2(cos(ce), sin(ce), -sin(ce), cos(ce));
    mat2 fe = mat2(cos(de), sin(de), -sin(de), cos(de));
    y_.xz *= ee;
    y_.xy *= fe;
    vec3 ge = vec3(1., .5, .5);
    ge += vec3(t_ * 2., t_, -2.);
    ge.xz *= ee;
    ge.xy *= fe;
    float s = .1;
    float ae = 1.;
    vec3 Nb = vec3(0.);
    for (int r = 0; r < 20; r++) {
        vec3 p = ge + s * y_ * .5;
        p = abs(vec3(0.850) - mod(p, vec3(0.850 * 2.)));
        float he = 0., a = 0.;
        for (int w_ = 0; w_ < 15; w_++) {
            p = abs(p) / dot(p, p) - 0.53;
            a += abs(length(p) - he);
            he = length(p);
        }
        float ie = max(0., 0.300 - a * a * 1e-3);
        a *= a * a;
        if (r > 6) {
            ae *= 1. - ie;
        }
        Nb += ae;
        Nb += vec3(s, s * s, s * s * s * s) * a * 0.0015 * ae;
        ae *= 0.730;
        s += 0.1;
    }
    Nb = mix(vec3(length(Nb)), Nb, 0.850);
    return vec4(Nb * .01, 1.);
}

#define je(a) if (ke(a))

bool ke(float le) {
    float me = .5;
    float ne = texture(Sampler0, texCoord0).a * 255.;
    return abs(ne - le) < me;
}

void main() {
    vec4 l = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    je(254) { fragColor = x_(); return; }
    je(253) { fragColor = sd(); return; }
    je(252) { fragColor = Zd(); return; }
    je(251) { fragColor = Ta(); return; }
    je(250) { fragColor = Ya(); return; }
    je(249) { fragColor = wb(); return; }
    je(248) { fragColor = Gd(); return; }
    je(247) { fragColor = be(); return; }
    if (l.a < .02) {
        discard;
    }
    fragColor = l;
}

