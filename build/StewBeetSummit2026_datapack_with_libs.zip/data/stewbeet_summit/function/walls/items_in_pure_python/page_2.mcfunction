
#> stewbeet_summit:walls/items_in_pure_python/page_2
#
# @within	stewbeet_summit:walls/items_in_pure_python/show
#

data modify entity 20180612-2026-2002-2098-202000000003 text set value ["", {"text": "Just drop a texture (3/5)\n\n", "bold": true, "color": "gold"}, {"text": "Put ", "color": "white"}, {"text": "ruby.png", "bold": true, "color": "aqua"}, {"text": " in assets/textures/\n\n", "color": "white"}, [{"text": "S", "color": "#ff9100", "italic": false}, {"text": "t", "color": "#ff7c00"}, {"text": "e", "color": "#ff6700"}, {"text": "w", "color": "#ff5200"}, {"text": "B", "color": "#ff3e00"}, {"text": "e", "color": "#ff2900"}, {"text": "e", "color": "#ff1400"}, {"text": "t", "color": "#ff0000"}], {"text": " auto-detects it and builds the model + item_model reference.\n\n", "color": "white"}, {"text": "No JSON model files by hand.", "color": "#7F8C99", "italic": true}]
data modify entity 20180612-2026-2002-2098-202000000003 line_width set value 175
data modify entity 20180612-2026-2002-2098-202000000003 transformation.scale set value [0.6f, 0.6f, 0.6f]
data modify entity 20180612-2026-2002-2098-202100000003 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_left"
data modify entity 20180612-2026-2002-2098-202200000003 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_right"

