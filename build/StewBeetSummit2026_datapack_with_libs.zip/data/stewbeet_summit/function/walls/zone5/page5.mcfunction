
#> stewbeet_summit:walls/zone5/page5
#
# @within	stewbeet_summit:walls/zone5/show
#

data modify entity 20180612-2026-2002-2098-202000000005 text set value ["", {"text": "Bookshelf (6/7)\n\n", "bold": true, "color": "gold"}, {"text": "A modular toolbox of many many datapack ", "color": "white"}, {"text": "utilities by the ", "color": "white"}, {"text": "Bookshelf", "bold": true, "color": "aqua"}, {"text": " team.\n\n", "color": "white"}, {"text": "Call ", "color": "white"}, {"text": "#bs.math:...", "bold": true, "color": "aqua"}, {"text": " in a function and ", "color": "white"}, {"text": "StewBeet pulls in just that module.\n\n", "color": "white"}, {"text": "github.com/mcbookshelf/bookshelf", "color": "#8BE9FD", "underlined": true, "click_event": {"action": "open_url", "url": "https://github.com/mcbookshelf/bookshelf"}, "hover_event": {"action": "show_text", "value": "Open https://github.com/mcbookshelf/bookshelf"}}]
data modify entity 20180612-2026-2002-2098-202000000005 line_width set value 175
data modify entity 20180612-2026-2002-2098-202000000005 transformation.scale set value [0.6, 0.6, 0.6]
data modify entity 20180612-2026-2002-2098-202100000005 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_left"
data modify entity 20180612-2026-2002-2098-202200000005 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_right"

