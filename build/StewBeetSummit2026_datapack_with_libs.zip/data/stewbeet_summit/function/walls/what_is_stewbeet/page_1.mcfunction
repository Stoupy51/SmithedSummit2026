
#> stewbeet_summit:walls/what_is_stewbeet/page_1
#
# @executed	positioned 211.5 101.0 -18.5 & rotated 90 0
#
# @within	stewbeet_summit:walls/what_is_stewbeet/show
#

data modify entity 20180612-2026-2002-2098-202000000000 text set value ["", {"text": "The old way (2/4)\n\n", "bold": true, "color": "gold"}, {"text": "A modern datapack means hundreds of hand-written files: models, loot tables, recipes, lang, item components...\n\n", "color": "white"}, {"text": "Tedious. Error-prone. Hard to maintain.", "color": "#7F8C99", "italic": true}]
data modify entity 20180612-2026-2002-2098-202000000000 line_width set value 175
data modify entity 20180612-2026-2002-2098-202000000000 transformation.scale set value [0.6, 0.6, 0.6]
data modify entity 20180612-2026-2002-2098-202100000000 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_left"
data modify entity 20180612-2026-2002-2098-202200000000 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_right"

