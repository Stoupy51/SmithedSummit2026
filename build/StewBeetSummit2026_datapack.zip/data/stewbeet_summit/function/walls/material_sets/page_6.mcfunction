
#> stewbeet_summit:walls/material_sets/page_6
#
# @executed	positioned 197.5 101.0 -27.5 & rotated 0 0
#
# @within	stewbeet_summit:walls/material_sets/show
#

data modify entity 20180612-2026-2002-2098-202000000007 text set value ["", {"text": "Any vanilla tier (7/9)\n\n", "bold": true, "color": "gold"}, {"text": "Base the set on any tier: ", "color": "white"}, {"text": "wood", "bold": true, "color": "aqua"}, {"text": ", ", "color": "white"}, {"text": "stone", "bold": true, "color": "aqua"}, {"text": ", ", "color": "white"}, {"text": "gold", "bold": true, "color": "aqua"}, {"text": ", ", "color": "white"}, {"text": "copper", "bold": true, "color": "aqua"}, {"text": ", ", "color": "white"}, {"text": "iron", "bold": true, "color": "aqua"}, {"text": ", ", "color": "white"}, {"text": "diamond", "bold": true, "color": "aqua"}, {"text": ", ", "color": "white"}, {"text": "netherite", "bold": true, "color": "aqua"}, {"text": ".\n\n", "color": "white"}, {"text": "Modifiers auto-route: ", "color": "white"}, {"text": "armor & toughness to ", "color": "white"}, {"text": "armor", "bold": true, "color": "aqua"}, {"text": ", ", "color": "white"}, {"text": "damage & mining to ", "bold": true, "color": "aqua"}, {"text": "tools", "bold": true, "color": "aqua"}, {"text": ".\n\n", "color": "white"}, {"text": "Stone -> chainmail, wood -> leather.", "color": "#7F8C99", "italic": true}]
data modify entity 20180612-2026-2002-2098-202000000007 line_width set value 175
data modify entity 20180612-2026-2002-2098-202000000007 transformation.scale set value [0.55, 0.55, 0.55]
data modify entity 20180612-2026-2002-2098-202100000007 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_left"
data modify entity 20180612-2026-2002-2098-202200000007 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_right"

