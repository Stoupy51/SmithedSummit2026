
#> stewbeet_summit:walls/material_sets/page_3
#
# @executed	positioned 197.5 101.0 -27.5 & rotated 0 0
#
# @within	stewbeet_summit:walls/material_sets/show
#

data modify entity 20180612-2026-2002-2098-202000000007 text set value ["", {"text": "Crafts, for free (4/9)\n\n", "bold": true, "color": "gold"}, {"text": "Every generated item is already wired up:\n\n- Raw & dust ", "color": "white"}, {"text": "smelt", "bold": true, "color": "aqua"}, {"text": " to the ingot\n- Shapeless: 9 ingots ", "color": "white"}, {"text": "<->", "bold": true, "color": "aqua"}, {"text": " 1 block\n- Shapeless: 9 nuggets ", "color": "white"}, {"text": "<->", "bold": true, "color": "aqua"}, {"text": " 1 ingot\n", "color": "white"}, {"text": "- Tools & armor get their crafting ", "color": "white"}, {"text": "shapes", "bold": true, "color": "aqua"}, {"text": "\n- Melt old gear back into ", "color": "white"}, {"text": "nuggets", "bold": true, "color": "aqua"}, {"text": "\n- The ore ", "color": "white"}, {"text": "drops", "bold": true, "color": "aqua"}, {"text": " when no silk touch\n- ...\n\n", "color": "white"}, {"text": "Blasting + pulverizing (2x dust) too.", "color": "#7F8C99", "italic": true}]
data modify entity 20180612-2026-2002-2098-202000000007 line_width set value 220
data modify entity 20180612-2026-2002-2098-202000000007 transformation.scale set value [0.5, 0.5, 0.5]
data modify entity 20180612-2026-2002-2098-202100000007 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_left"
data modify entity 20180612-2026-2002-2098-202200000007 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_right"

