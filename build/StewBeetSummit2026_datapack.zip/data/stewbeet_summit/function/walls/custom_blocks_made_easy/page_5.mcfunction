
#> stewbeet_summit:walls/custom_blocks_made_easy/page_5
#
# @within	stewbeet_summit:walls/custom_blocks_made_easy/show
#

data modify entity 20180612-2026-2002-2098-202000000004 text set value ["", {"text": "States & facing (6/6)\n\n", "bold": true, "color": "gold"}, {"text": "Add an ", "color": "white"}, {"text": "_on", "bold": true, "color": "aqua"}, {"text": " texture and the block gets a powered state for free.\n\nSet ", "color": "white"}, {"text": "block_facing", "bold": true, "color": "aqua"}, {"text": " and ", "color": "white"}, [{"text": "S", "color": "#ff9100", "italic": false}, {"text": "t", "color": "#ff7c00"}, {"text": "e", "color": "#ff6700"}, {"text": "w", "color": "#ff5200"}, {"text": "B", "color": "#ff3e00"}, {"text": "e", "color": "#ff2900"}, {"text": "e", "color": "#ff1400"}, {"text": "t", "color": "#ff0000"}], {"text": " builds ", "color": "white"}, {"text": "directional", "bold": true, "color": "aqua"}, {"text": " variants, all recognized from names like electric_furnace_front_on.png", "color": "white"}]
data modify entity 20180612-2026-2002-2098-202000000004 line_width set value 175
data modify entity 20180612-2026-2002-2098-202000000004 transformation.scale set value [0.6f, 0.6f, 0.6f]
data modify entity 20180612-2026-2002-2098-202100000004 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_left"
data modify entity 20180612-2026-2002-2098-202200000004 item.components."minecraft:item_model" set value "stewbeet_summit:gray_nav_arrow_right"

