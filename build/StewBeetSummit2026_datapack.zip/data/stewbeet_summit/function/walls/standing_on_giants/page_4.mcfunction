
#> stewbeet_summit:walls/standing_on_giants/page_4
#
# @within	stewbeet_summit:walls/standing_on_giants/show
#

# Page 5/7 "The Smithed Ecosystem": swap this page's text, wrap width and text scale into the display
data modify entity 20180612-2026-2002-2098-202000000005 text set value ["", {"text": "The Smithed ecosystem (5/7)\n\n", "bold": true, "color": "gold"}, {"text": "Crafter", "bold": true, "color": "aqua"}, {"text": " for NBT recipes, ", "color": "white"}, {"text": "Custom Blocks", "bold": true, "color": "aqua"}, {"text": " for placement - auto-wired.\n\nSmithed also sets shared ", "color": "white"}, {"text": "conventions", "bold": true, "color": "aqua"}, {"text": " so packs stay interoperable, even in normal worlds outside the ecosystem.\n\n", "color": "white"}, {"text": "Smithed Weld", "bold": true, "color": "aqua"}, {"text": " merges your pack with its dependencies on build.\n\n", "color": "white"}, ["", {"font": "summit_icons:icons", "translate": "summit_icons.smithed"}, {"text": " "}, {"text": "docs.smithed.dev", "color": "#8BE9FD", "underlined": true, "click_event": {"action": "open_url", "url": "https://docs.smithed.dev/"}, "hover_event": {"action": "show_text", "value": "Open https://docs.smithed.dev/"}}]]
data modify entity 20180612-2026-2002-2098-202000000005 line_width set value 220
data modify entity 20180612-2026-2002-2098-202000000005 transformation.scale set value [0.5f, 0.5f, 0.5f]

# Gray the arrow that has no page beyond it (left on the first page, right on the last)
data modify entity 20180612-2026-2002-2098-202100000005 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_left"
data modify entity 20180612-2026-2002-2098-202200000005 item.components."minecraft:item_model" set value "stewbeet_summit:nav_arrow_right"

# Refresh the centered "Open link" prompt and restore its clickable hitbox
data modify entity 20180612-2026-2002-2098-202300000005 text set value ["", {"font": "summit_icons:icons", "translate": "summit_icons.smithed"}, {"text": " "}, {"text": "Open link", "color": "#8BE9FD", "underlined": true}]
data modify entity 20180612-2026-2002-2098-202400000005 width set value 0.75f
data modify entity 20180612-2026-2002-2098-202400000005 height set value 0.75f

