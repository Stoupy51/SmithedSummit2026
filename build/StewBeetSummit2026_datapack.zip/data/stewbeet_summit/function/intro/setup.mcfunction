
#> stewbeet_summit:intro/setup
#
# @within	stewbeet_summit:entities/summon
#

# Background black hole (underground)
execute unless entity 20180612-2026-2002-2098-201000000000 run summon item_display 198.5 54.0 -20.5 {UUID:uuid("20180612-2026-2002-2098-201000000000"),"item": {"id": "stone", "components": {"minecraft:item_model": "stewbeet_summit:bg_black_hole"}, "count": 1}, "Tags": ["stewbeet_summit.bg_black_hole", "summit.booth_entity.stewbeet_summit", "summit.static"], "brightness": {"block": 15, "sky": 15}, "transformation": {"left_rotation": [0.0, 0.0, 0.0, 1.0], "right_rotation": [0.0, 0.0, 0.0, 1.0], "scale": [16.69, 9.8, -16.69], "translation": [0.0, 0.0, 0.0]}}

# Logo, title, and arrows at the entrance
execute unless entity 20180612-2026-2002-2098-201000000001 run summon item_display 196.5 103.5 -9.9 {UUID:uuid("20180612-2026-2002-2098-201000000001"),"item": {"id": "stone", "components": {"minecraft:item_model": "stewbeet_summit:logo"}, "count": 1}, "Tags": ["stewbeet_summit.logo", "summit.booth_entity.stewbeet_summit", "summit.static"], "brightness": {"block": 15, "sky": 15}, "transformation": {"left_rotation": [0.0, 0.0, 0.0, 1.0], "right_rotation": [0.0, 0.0, 0.0, 1.0], "scale": [2.5, 2.5, 5.0], "translation": [0.0, 0.0, 0.0]}, "Rotation": [180, 0]}
execute unless entity 20180612-2026-2002-2098-201000000002 run summon item_display 196.5 103.0 -9.6 {UUID:uuid("20180612-2026-2002-2098-201000000002"),"item": {"id": "stone", "components": {"minecraft:item_model": "stewbeet_summit:title"}, "count": 1}, "Tags": ["stewbeet_summit.title", "summit.booth_entity.stewbeet_summit", "summit.static"], "brightness": {"block": 15, "sky": 15}, "transformation": {"left_rotation": [0.0, 0.0, 0.0, 1.0], "right_rotation": [0.0, 0.0, 0.0, 1.0], "scale": [3.5, 3.5, 3.5], "translation": [0.0, 0.0, 0.0]}, "Rotation": [0, 0]}
execute unless entity 20180612-2026-2002-2098-201000000003 run summon item_display 197.6875 99.4375 -10.5 {UUID:uuid("20180612-2026-2002-2098-201000000003"),"item": {"id": "stone", "components": {"minecraft:item_model": "stewbeet_summit:arrow"}, "count": 1}, "Tags": ["stewbeet_summit.arrow", "summit.booth_entity.stewbeet_summit", "summit.static"], "brightness": {"block": 15, "sky": 15}, "transformation": {"left_rotation": [0.0, 0.0, 0.172, 0.985], "right_rotation": [0.0, 0.0, 0.0, 1.0], "scale": [5.0, 5.0, 5.0], "translation": [0.0, 0.0, 0.0]}}
execute unless entity 20180612-2026-2002-2098-201000000004 run summon item_display 198.9375 98.125 -4.0 {UUID:uuid("20180612-2026-2002-2098-201000000004"),"item": {"id": "stone", "components": {"minecraft:item_model": "stewbeet_summit:arrow"}, "count": 1}, "Tags": ["stewbeet_summit.arrow", "summit.booth_entity.stewbeet_summit", "summit.static"], "brightness": {"block": 15, "sky": 15}, "transformation": {"left_rotation": [0.0, 0.0, 0.0, 1.0], "right_rotation": [0.0, 0.0, 0.0, 1.0], "scale": [5.0, 5.0, 2.5], "translation": [0.0, 0.0, 0.0]}, "Rotation": [-90, 0]}

# Another time the logo and title at the real entrance
execute unless entity 20180612-2026-2002-2098-201000000005 run summon item_display 207.0 103.5 -16.0 {UUID:uuid("20180612-2026-2002-2098-201000000005"),"item": {"id": "stone", "components": {"minecraft:item_model": "stewbeet_summit:logo"}, "count": 1}, "Tags": ["stewbeet_summit.logo", "summit.booth_entity.stewbeet_summit", "summit.static"], "brightness": {"block": 15, "sky": 15}, "transformation": {"left_rotation": [0.0, 0.0, 0.0, 1.0], "right_rotation": [0.0, 0.0, 0.0, 1.0], "scale": [2.5, 2.5, 5.0], "translation": [0.0, 0.0, 0.0]}, "Rotation": [90, 0]}
execute unless entity 20180612-2026-2002-2098-201000000006 run summon item_display 207.25 102.5 -16.0 {UUID:uuid("20180612-2026-2002-2098-201000000006"),"item": {"id": "stone", "components": {"minecraft:item_model": "stewbeet_summit:title"}, "count": 1}, "Tags": ["stewbeet_summit.title", "summit.booth_entity.stewbeet_summit", "summit.static"], "brightness": {"block": 15, "sky": 15}, "transformation": {"left_rotation": [0.0, 0.0, 0.0, 1.0], "right_rotation": [0.0, 0.0, 0.0, 1.0], "scale": [2, 2, 2], "translation": [0.0, 0.0, 0.0]}, "Rotation": [-90, 0]}

# Button to get out of the underground
execute unless entity 20180612-2026-2002-2098-201000000007 run summon item_display 210.0 52.5 -26.0 {UUID:uuid("20180612-2026-2002-2098-201000000007"),"item": {"id": "minecraft:pale_oak_button", "count": 1}, "Tags": ["stewbeet_summit.underground_button", "summit.booth_entity.stewbeet_summit", "summit.static"], "brightness": {"block": 15, "sky": 15}, "transformation": {"left_rotation": [0.0, 0.0, 0.0, 1.0], "right_rotation": [0.0, 0.0, 0.0, 1.0], "scale": [1.5, 1.5, 1.5], "translation": [0.0, 0.0, 0.0]}, "Rotation": [0, 0]}
execute unless entity 20180612-2026-2002-2098-201000000008 run summon interaction 210.0 52.5 -26.0 {UUID:uuid("20180612-2026-2002-2098-201000000008"),"Tags": ["summit.booth_entity.stewbeet_summit", "summit.static", "summit.interactable"], "response": true, "width": 1.2, "height": 1.2, "data": {"summit_interactable": {"on_right_click": "execute on target run effect give @s levitation 4 13 true"}}}

# Stoupy Mannequin (deferred: even with its death animation fast-forwarded in
# entities/kill, the freshly killed corpse still holds the UUID this tick)
schedule function stewbeet_summit:intro/mannequin 2t replace

